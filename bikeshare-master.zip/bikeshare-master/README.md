## Bikeshare Project (Data Analysis Nanodegree)

I found the following resources useful when completing this assignment: 

https://stackoverflow.com/questions/25873772/how-to-filter-a-dataframe-of-dates-by-a-particular-month-day

https://www.youtube.com/watch?v=yCgJGsg0Xa4

The bikeshare data for Chicago, New York City and Washington DC [can be downloaded from my Dropbox](https://www.dropbox.com/s/2wl83d76dsugrqg/bikeshare.zip?dl=0) 

#### author: Antonio Rueda-Toicen 
#### antonio.rueda.toicen " at " gmail ( dot ) com
